本ディレクトリに収録されている合成音声ファイルは、
下記のソフトウェアを用いて作成しました。

音声合成システム Open JTalk: http://open-jtalk.sourceforge.net/
音響モデル Mei: http://www.mmdagent.jp/
